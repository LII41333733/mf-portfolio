use restaurant_db;

INSERT INTO tables
  (name, email, phone, isWaiting)
VALUES
  ('Ahmed', 'ahmed@example.com', '000-000-0000', FALSE);

INSERT INTO tables
  (name, email, phone, isWaiting)
VALUES
  ('Saima', 'saima@example.com', '555-555-5555', TRUE);
